import{default as m}from"../components/pages/_layout.svelte-1fad229c.js";import"./index-d4d20d67.js";export{m as component};
