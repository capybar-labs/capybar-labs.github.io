import{default as m}from"../components/error.svelte-bb8b4ef6.js";import"./index-d4d20d67.js";export{m as component};
