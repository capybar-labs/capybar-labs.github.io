import{_ as t}from"./_page-802cc2a3.js";import{default as m}from"../components/pages/_page.svelte-4ab55ccc.js";import"./index-d4d20d67.js";export{m as component,t as shared};
